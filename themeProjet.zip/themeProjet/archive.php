<?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?> 

    <div class="post bloc w60vh"> 

            <p class="centerligne"><a class="centerligne fs50 clracs"href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?>  </a></p> 
            <div class="dflex flex_end"> Auteur: <?php the_author() ?> </div><br>
            <div class="dflex flex_end"> Publié le : <?php the_time('j F Y H:m:s') ?> </div><br>
            <div class="post_content "> <?php the_content(); ?></div> 
        </div> 
        <br>

        <?php the_title(); ?>  
        <p class="postmetadata clryellow3">   
            <?php the_time('j F Y') ?> par <?php the_author() ?> 
            | Cat&eacute;gorie: <?php the_category(', ') ?> 
            | <?php comments_popup_link('Pas de commentaires', '1 Commentaire', '% Commentaires'); ?> 
            <?php edit_post_link('Editer', ' &#124; ', ''); ?>
            <br>
            <div class="trait w60vh"></div><br>
        </p>

        <?php endwhile; ?>

        <div class="navigation"> <?php posts_nav_link(' - ','page suivante','page pr&eacute;c&eacute;dente'); ?> </div>

    <?php endif; ?> 




