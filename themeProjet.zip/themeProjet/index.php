<?php get_header(); ?>
    <div class="top-section">
                <?php echo do_shortcode('[recent_post_slider design="design-1" media_size="full" show_category_name="false" dots="false" show_date="false" show_author="false" autoplay="false"]'); ?> 
    </div>
    <div class="dflex flex_column"> 
            <!-- ajout de ma nouvelle widget area -->
        <?php if ( is_active_sidebar( 'new-widget-area' ) ) : ?>
        <div id="header-widget-area" class="nwa-header-widget widget-area" role="complementary">
        <?php dynamic_sidebar( 'new-widget-area' ); ?>
        </div>
        <?php endif; ?>
        <!-- fin nouvelle widget area -->

        <div class="dflex centerligne bgarticle flex_column margintop10ps w100vh" id="content"> 
            <p class="titre_groupe_article fs20 margintop3ps centerligne">DERNIERS ARTICLES</p>
            <hr>
            <div class="dflex w70ps divArticle space_around">
                <?php $nbarticle = 0; ?>
                <?php if(have_posts()) : ?><?php while(have_posts()) : the_post();  ?> 
                        
                    <div class="post">


                        <?php
                            // On vérifie si l'article contient une Image à la Une
                            if( has_post_thumbnail() ) { ?>

                            <div class="left">

                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" ><?php the_post_thumbnail(); ?></a>

                            </div>
                            <?php
                            $nbarticle++;
                            }
                            else {
                                // Si l'article n'a pas d'Image à la Une, on récupère la 1ère image attachée
                                $attachments = get_children(
                                    array(
                                    'post_parent' => get_the_ID(),
                                    'post_type' => 'attachment',
                                    'post_mime_type' => 'image',
                                    'orderby' => 'menu_order',
                                    'order' => 'ASC',
                                    'numberposts' => 1
                                    )
                                );

                            if( $attachments ) {
                            foreach( $attachments as $attachment ) :
                            ?>
                            <div class="left">
                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" ><?php echo "<p class='h10vh w20vh'>".wp_get_attachment_image($attachment->ID , 'thumbnail')."</p>"; ?></a>
                            </div>

                            <?php
                            endforeach;
                            }
                            }
                        ?>

                        
                        <p><a class="fs27 titrearticle clrgrisprojet"href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?>  </a></p>
                        <hr>
                        <div class="post_content textepost dflex justify_content_center item_center flex_column fs15"> <?php the_excerpt(); ?></div> 
                    </div> 
                    <br>


                <?php endwhile; ?> <?php endif; ?>
            </div>        
        </div>



    </div>

    <div class="dflex flex_column w100ps">

        <p class="classement clrgrisprojet fs27 margintop5ps titrearticle">classement</p>
        <?php /* My widget place */
        if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('my_widget_place') ) : ?>
        <?php endif ?>


    </div>

    <hr class="w100ps clrgrisprojet">
    <img class="nextmatch" src="wp-content/themes/themeProjet/img/matchsnext.png" >
    
    <?php /* My widget perso */
        if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('my_widget_perso') ) : ?>
    <?php endif ?>

    <div class="dflex justify_content_center divLogopartenaire w100ps">
        <img class="logopartenaire" src="wp-content/themes/themeProjet/img/logo.png" alt="">
        <p class="barrelogopartenaire"></p>
    </div>
 

    <?php /* My widget partenaire */
        if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('my_widget_partenaires') ) : ?>
    <?php endif ?>

<?php get_footer(); ?> 


