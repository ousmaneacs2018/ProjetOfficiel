<?php get_header(); ?>

<div ><?php the_content(); ?> </div>


 
<?php get_footer(); ?> 


