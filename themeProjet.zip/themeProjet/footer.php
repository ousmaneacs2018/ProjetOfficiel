<footer class="bg-blue d-flex j-c-center p-t-50 p-b-50 a-i-center" id="footer">
<div class="d-flex j-c-between w65">
	<div class="ft-white ">
		<h1 class="b-bottom p-b-20 fw-bold barlow fs-28">Contact</h1> 
		<p class="ft-lt-blue p-t-20 fs15">Pré de la Maladière, 70170 Port-sur-Saone </p>
		<p class="ft-lt-blue paddingtop15px paddingbottom15px fs15">0384781170</p>
		<p class="ft-lt-blue  fs15">Portusiencsfoot@orange.fr</p>
		
	</div>
		
	<div class="d-flex a-i-center ">
		<a href="#" class="ft-lt-blue fa fa-facebook fa-5x "></a>
		<a href="#" class="m-l-50 ft-lt-blue fa fa-youtube fa-5x"></a>
	</div>
</div>
</footer>

<script src="./wp-content/themes/themeProjet/js/projetIntegration.js"> </script>

<?php wp_footer(); ?>


</body> 
</html>