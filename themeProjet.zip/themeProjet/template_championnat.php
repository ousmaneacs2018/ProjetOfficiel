<?php
/*
Template Name: championnat
*/
?>

<?php get_header(); ?>

<div class="dflex w100vh blocsinglew100ps centerligne flex_column" id="content"> 

    <?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?> 

    <div class="post "> 
        <p><a class=" fs30"href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?>  </a></p> 
        <div class="post_content "> <?php the_content(); ?></div>
    </div> 
    <br>
    <p class="postmetadata clryellow3">   
              
        <br>
    </p>

    <?php endwhile; ?>


    <?php endif; ?> 
</div>

<?php get_footer(); ?> 