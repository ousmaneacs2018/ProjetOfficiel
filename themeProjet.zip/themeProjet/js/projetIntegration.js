


var nbclick = 1;
//Gestion Responsive

var inputSearch = document.getElementById('searchform');
inputSearch.style.visibility = "hidden";

var loupe = document.getElementById('loupe');

loupe.addEventListener('click',function(){
	nbclick++;
	if(nbclick == 2){
		inputSearch.style.visibility = "hidden";		
	}
	else{
		inputSearch.style.visibility = "visible";
		nbclick=1;
	}
	
	});



var content = document.querySelector('#hamburger-content');
var sidebarBody = document.querySelector('#hamburger-sidebar-body');
var button = document.querySelector('#hamburger-button');
var overlay = document.querySelector('#hamburger-overlay');
var activatedClass = 'hamburger-activated';

sidebarBody.innerHTML = content.innerHTML;			


button.addEventListener('click', function(e) {
	e.preventDefault();

	this.parentNode.classList.add(activatedClass);
});

button.addEventListener('keydown', function(e) {
	if (this.parentNode.classList.contains(activatedClass))
	{
		if (e.repeat === false && e.which === 27)
			this.parentNode.classList.remove(activatedClass);
	}
});

overlay.addEventListener('click', function(e) {
	e.preventDefault();

	this.parentNode.classList.remove(activatedClass);
});