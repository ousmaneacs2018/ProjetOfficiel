<i id="loupe" class="clrwhite fas fs18 fa-search mr40px"></i>
<form class="diblock vbottom" method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
    <div class="centerligne "> 
        <input type="text" value="<?php the_search_query(); ?>" name="s" id="s" /> 
        <input type="submit" id="searchsubmit" value="Chercher" /> 
    </div> 
</form>