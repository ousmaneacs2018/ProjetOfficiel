<?php
/*
Template Name: club
*/
?>

<?php get_header(); ?>

<div class="dflex w100vh Resp_calendrier w100ps centerligne flex_column" id="content"> 

    <?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?> 

    <div class="post"> 
        <div class="w65ps center">
            <h2 class="w15ps b-portusien txt_center semiBold fs18 pt10px pb10px pr20px pl20px bold clrblueportusien mb30px barlow-condensed fs30"href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></h2>
        </div> 
        <div class="post_content "> <?php the_content(); ?></div>
    </div> 
    <br>
    <p class="postmetadata clryellow3">   
        <?php the_time('j F Y') ?> par <?php the_author() ?> 
        | Cat&eacute;gorie: <?php the_category(', ') ?> 
        | <?php comments_popup_link('Pas de commentaires', '1 Commentaire', '% Commentaires'); ?> 
        <?php edit_post_link('Editer', ' &#124; ', ''); ?>                
        <br>
    </p>

    <?php endwhile; ?>


    <?php endif; ?> 
</div>

<?php get_footer(); ?> 
