<?php
/*
Template Name: csp tv
*/
?>

<?php get_header(); ?>

<div class="dflex h100vh mt50px mb50px  w100ps centerligne flex_column" id="content"> 

    <?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?> 

    <div class="h100ps"> 
        <div class="w65ps center">
            <h2 class="w15ps b-portusien Resp_titre_csptv txt_center semiBold fs18 pt10px pb10px pr20px pl20px bold clrblueportusien mb30px barlow-condensed fs30"href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></h2>
        </div> 
        <div class="post_content "> <?php the_content(); ?></div>
    </div> 
    <br>

    <?php endwhile; ?>


    <?php endif; ?> 
</div>


<?php get_footer(); ?> 
