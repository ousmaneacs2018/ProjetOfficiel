<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head profile="http://gmpg.org/xfn/11">   
<title>

    <?php bloginfo('name') ?><?php if ( is_404() ) : ?> &raquo; <?php _e('Not Found') ?><?php elseif ( is_home() ) : ?> &raquo; 
    <?php bloginfo('description') ?><?php else : ?><?php wp_title() ?><?php endif ?>

</title>   
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" /> 
<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats --> 
<base href="http://localhost/projetIntegration/">
<link href="https://fonts.googleapis.com/css?family=Barlow" rel="stylesheet">
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" /> 
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" /> 
<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" /> 
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" /><?php wp_head(); ?>   <?php wp_get_archives('type=monthly&format=link'); ?> <?php //comments_popup_script(); <?php wp_head(); ?>   
</head> 

<body class="h100vh bggrisclair">
    <header class="dflex flex_column bgblue h335px pt100px">
        <div >
            <button class="btn_hamburger" id="hamburger-button">&#9776;</button>                
            <div id="hamburger-sidebar">
                <div id="hamburger-sidebar-header"></div>
                <div id="hamburger-sidebar-body"></div>
            </div>
            <div id="hamburger-overlay"></div>
        </div>
        <div  id="hamburger" class="relative w100ps">
            <img class="absolute center w165px left0 right0" src="./wp-content/themes/themeProjet/img/logo.png">

            <div class="dflex w100ps space_between">
                <div class="bb1 b-color-white w40ps Resp_icone_reseausociaux txt_right pb20px">
                    <a class="clrwhite"><i class="fab fs30 fa-facebook mr40px"></i></a>
                    <a class="clrwhite" href=""><i class="fab fs30 fa-youtube"></i></a>
                </div>
                
                <div class="bb1 b-color-white Resp_icone_search w40ps">
                    <a class="    txtdecorationnone  mr40px" > <p class="txtdecorationnone barlow uppercase clrwhite fs18"><?php wp_loginout(); ?></p></a>
<?php               include(TEMPLATEPATH . '/searchform.php'); ?>
                </div>
            </div>

            <div id="hamburger-content">
<?php           wp_nav_menu( array(
                    'menu'              => 'top-menu',
                    'theme_location'    => 'primary',
                    'container'     => 'div',
                    'container_id'      => 'top-navigation-primary',
                    'conatiner_class'   => 'top-navigation',
                    'menu_class'        => 'menu main-menu menu-depth-0 menu-even dflex Resp_menu nav-top space_evenly w1270px center mt20px', 
                    'echo'          => true,
                    'items_wrap'        => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                    'depth'         => 10, 
                    'walker'        => new themeslug_walker_nav_menu
                ) ); ?>
            </div>
        </div>
    </header>


