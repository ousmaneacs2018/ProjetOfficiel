<?php
/*
Template Name: contact
*/
?>

<?php get_header(); ?>

<div class="dflex w100vh blocsingle w100ps justify_content_center align_item_center flex_column" id="content"> 

    <div class="d-flex j-c-between ">
        <div class="ft-white ">
            <h1 class="clrblack b-bottom p-b-20 fw-bold barlow fs-28">PRISE DE CONTACT</h1> 
            <p class="clrblack p-t-20 fs15">Pré de la Maladière, 70170 Port-sur-Saone </p>
            <p class="clrblack paddingtop15px paddingbottom15px fs15">0384781170</p>
            <p class="clrblack  fs15">Portusiencsfoot@orange.fr</p>
            
        </div>
    </div>

</div>

<?php get_footer(); ?> 
