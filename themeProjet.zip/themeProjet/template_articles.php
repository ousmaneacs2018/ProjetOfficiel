<?php
/*
Template Name: articles
*/
?>

<?php get_header(); ?>



<?php /* My widget partenaire */
        if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('my_widget_articles') ) : ?>
    <?php endif ?>

<?php wp_get_archives('type=monthly'); ?>





<?php get_footer(); ?> 
