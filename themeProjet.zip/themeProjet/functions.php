<?php 
if ( function_exists('register_sidebar') ) register_sidebar();

//Modifie le texte de suite de l'excerpt
function krol_excerpt_more($more){
return ' <a class="more-link underline " href="' .get_permalink(). '"><br><br>' . 'lire la suite' . '</a>';
}
add_filter('excerpt_more', 'krol_excerpt_more');

function krol_setup(){
    require_once get_template_directory()."/include/class-wp-walker.php";

    //active la gestion des menus
    register_nav_menus( array('primary' => 'principal') );
}

add_action('after_setup_theme', 'krol_setup');

function wpb_adding_styles(){
    wp_enqueue_style('parent-theme', get_template_directory_uri().'/style.css');
}

add_action('wp_enqueue_scripts', 'wpb_adding_styles');

add_filter( 'script_loader_tag', function( $tag, $handle ) {
 	if ( isset( $_REQUEST['action'] ) && 'elementor' === $_REQUEST['action'] ) {
 		return str_replace( ' src', ' data-cfasync="false" src', $tag ); 
	}
 	return $tag;
 }, 10, 2 );


 // Enable shortcodes in text widgets
add_filter('widget_text','do_shortcode');

function header_widgets_init() {
 
    register_sidebar( array(
   
    'name' => 'Ma nouvelle zone de widget',
    'id' => 'new-widget-area',
    'before_widget' => '<div class="nwa-widget">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="nwa-title">',
    'after_title' => '</h2>',
    ) );
   }
   
   add_action( 'widgets_init', 'header_widgets_init' );


   if ( function_exists('register_sidebar') ){
    register_sidebar(array(
      'name' => 'my_widget_place',
      'before_widget' => '<div class="margintop5ps" id="my-widget">',
      'after_widget' => '</div>',
      'before_title' => '',
      'after_title' => '',
    ));
    register_sidebar(array(
        'name' => 'my_widget_perso',
        'before_widget' => '<div class=" h20vh " id="my_widget_perso">',
        'after_widget' => '</div>',
        'before_title' => '',
        'after_title' => '',
      ));
      register_sidebar(array(
        'name' => 'my_widget_partenaires',
        'before_widget' => '<div class=" h20vh " id="my_widget_partenaires">',
        'after_widget' => '</div>',
        'before_title' => '',
        'after_title' => '',
      ));
      register_sidebar(array(
        'name' => 'my_widget_articles',
        'before_widget' => '<div class=" h80vh dflex bgarticle flex_wrap flex_column w100vh" id="my_widget_articles">',
        'after_widget' => '</div>',
        'before_title' => '',
        'after_title' => '',
      ));
  }

   function catch_that_image() {
    global $post, $posts;
    $first_img = '';
    ob_start();
    ob_end_clean();
    $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
    $first_img = $matches [1] [0];
    
    if(empty($first_img)){ //Defines a default image
    $first_img = "/images/default.jpg";
    }
    return $first_img;
    }
    

    